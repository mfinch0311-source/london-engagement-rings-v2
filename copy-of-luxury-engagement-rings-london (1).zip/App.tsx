
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import BestRings from './pages/BestRings';
import LocationsHub from './pages/LocationsHub';
import LocationDetail from './pages/LocationDetail';
import KnowledgeHub from './pages/KnowledgeHub';
import SupplierOfMonth from './pages/SupplierOfMonth';
import About from './pages/About';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/best-london-rings" element={<BestRings />} />
          <Route path="/locations" element={<LocationsHub />} />
          <Route path="/locations/:slug" element={<LocationDetail />} />
          <Route path="/knowledge-hub" element={<KnowledgeHub />} />
          <Route path="/supplier-of-the-month" element={<SupplierOfMonth />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
